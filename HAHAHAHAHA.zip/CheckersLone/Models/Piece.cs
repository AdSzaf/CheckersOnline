﻿namespace CheckersLone.Models
{
    public class Piece
    {
        public bool IsKing { get; set; }
        public bool IsWhite { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
    }
}
