﻿using System.Diagnostics;

public class Game
{
    public int Id { get; set; }
    public int Player1Id { get; set; }
    public int Player2Id { get; set; }
    public string Wynik { get; set; }

}
